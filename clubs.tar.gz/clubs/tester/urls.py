from django.conf.urls import patterns, url
from tester import views
from tester.models import club
from django.conf.urls.static import static

urlpatterns = patterns('',
	url(r'^$', views.index,),
	url(r'^about/$', views.about,),
	url(r'^clublist/$', views.clublist,),
	url(r'^club/.*$', views.clubname,))
