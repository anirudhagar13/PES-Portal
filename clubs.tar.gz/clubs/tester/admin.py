from django.contrib import admin

from tester.models import club,member,student,Event

class admin_club(admin.ModelAdmin):
	list_display=["club_name"]

class admin_event(admin.ModelAdmin):
	list_display=["event_name"]

class admin_student(admin.ModelAdmin):
	list_display=["usn","name"]

class admin_member(admin.ModelAdmin):
	list_display=["club_id","usn"]

admin.site.register(club,admin_club)
admin.site.register(member,admin_member)
admin.site.register(student,admin_student)
admin.site.register(Event,admin_event)

	
