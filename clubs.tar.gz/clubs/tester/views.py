from django.shortcuts import render, HttpResponse
from tester.models import club,member,student,Event

def index(request):
	#return HttpResponse("hello everyone")
	category_list = club.objects.order_by('club_id')
	event_list = Event.objects.all()
	context_dict = {'categories':category_list,'events' : event_list}
	#context_dict = {'boldmessage': "This Message is from the context.",'categories':category_list}

	return render(request, 'tester/index.html', context_dict)

def about(request):
	return render(request, 'tester/about.html')

def clublist(request):
	category_list = club.objects.order_by('club_id')
	context_dict = {'categories':category_list}
	return render(request, 'tester/club_list.html', context_dict)

def clubname(request):
	category_list = club.objects.order_by('club_id')
	member_list = student.objects.order_by('usn')
	event_list = Event.objects.all()
	objective_list = club.objects.all().filter()
	print(objective_list)
	member_dict = {'mcategories':member_list,'ccategories':category_list,'events' : event_list}
	return render(request, 'tester/club.html',member_dict,)



# Create your views here.
